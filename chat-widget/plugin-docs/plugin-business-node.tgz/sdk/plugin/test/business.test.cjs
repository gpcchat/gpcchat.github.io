const { test } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("node:crypto");
const { createServerClient, verifyWebhook } = require("../server.cjs");
const { createPlugin } = require("../gpc-plugin.js");
test("browser business methods use the host broker and never accept a server key", async () => {
  const calls = [];
  const plugin = createPlugin({
    provider: {
      request: async (args) => {
        calls.push(args);
        return { ok: true };
      },
    },
  });
  await plugin.orders.pay("po_1");
  await plugin.notifications.subscribe("status");
  await plugin.links.create({ path: "/event" });
  await plugin.camera.scan();
  await plugin.files.choose({ accept: ["application/pdf"] });
  await plugin.getLaunchContext();
  assert.deepEqual(
    calls.map((c) => c.method),
    [
      "gpc_plugin_orders_pay",
      "gpc_plugin_notifications_subscribe",
      "gpc_plugin_links_create",
      "gpc_plugin_camera_scan",
      "gpc_plugin_files_choose",
      "gpc_plugin_getLaunchContext",
    ],
  );
  assert.deepEqual(calls[0].params, [{ orderId: "po_1" }]);
});
test("server sends scoped requests and optimistic card updates", async () => {
  const calls = [];
  const client = createServerClient({
    apiKey: "gpk_test",
    fetch: async (url, init) => {
      calls.push({ url, init });
      return {
        ok: true,
        json: async () => ({ success: true, data: { version: 2 } }),
      };
    },
  });
  await client.events();
  await client.cards.update("pbm_x", {
    idempotencyKey: "paid:1",
    expectedVersion: 1,
    status: "paid",
    buttons: [],
  });
  assert.match(calls[0].url, /events\?after=$/);
  assert.equal(calls[1].init.method, "PATCH");
  assert.equal(calls[1].init.headers.Authorization, "Bearer gpk_test");
  assert.deepEqual(JSON.parse(calls[1].init.body), {
    idempotencyKey: "paid:1",
    expectedVersion: 1,
    status: "paid",
    buttons: [],
  });
});
test("server preserves conflict codes so callers can query latest card", async () => {
  const client = createServerClient({
    apiKey: "gpk_test",
    fetch: async () => ({
      ok: false,
      status: 409,
      json: async () => ({ success: false, code: "CARD_VERSION_CONFLICT" }),
    }),
  });
  await assert.rejects(
    client.cards.update("pbm_x", {
      expectedVersion: 1,
      idempotencyKey: "x",
      text: "changed",
    }),
    { code: "CARD_VERSION_CONFLICT", status: 409 },
  );
});
test("webhook verification binds exact bytes, event id, time and secret", () => {
  const now = 1800000000000,
    timestamp = String(now / 1000),
    eventId = "pe_1",
    secret = "webhook-secret";
  const rawBody = Buffer.from('{"kind":"order.paid","payload":"{}"}');
  const signature = crypto
    .createHmac("sha256", secret)
    .update(timestamp + "." + eventId + ".")
    .update(rawBody)
    .digest("hex");
  const input = { secret, timestamp, eventId, signature, rawBody, now };
  assert.equal(verifyWebhook(input), true);
  assert.equal(
    verifyWebhook({
      ...input,
      rawBody: Buffer.concat([rawBody, Buffer.from(" ")]),
    }),
    false,
  );
  assert.equal(verifyWebhook({ ...input, eventId: "pe_other" }), false);
  assert.equal(verifyWebhook({ ...input, now: now + 301000 }), false);
  assert.equal(verifyWebhook({ ...input, secret: "" }), false);
});
