const { test } = require('node:test');
const assert = require('node:assert/strict');
const { createPlugin } = require('../gpc-plugin.js');
test('SDK round trips JSON storage and removes listeners', async () => {
  const calls = [], listeners = [];
  const provider = { request: async args => { calls.push(args); return args.method.endsWith('_get') ? { value: '{"vote":2}' } : { saved: true }; }, on: (...args) => listeners.push(args), removeListener: (...args) => assert.deepEqual(args, listeners[0]) };
  const plugin = createPlugin({ provider });
  await plugin.storage.set('vote', { vote: 2 });
  assert.deepEqual(calls[0].params, [{ key: 'vote', value: '{"vote":2}' }]);
  assert.deepEqual(await plugin.storage.get('vote'), { vote: 2 });
  const stop = plugin.gravity.onChange(() => {}); stop();
});
test('wallet requests preserve the standard shape and reject host method injection', async () => {
  const calls = [], plugin = createPlugin({ provider: { request: async args => calls.push(args) } });
  await plugin.wallet.request({ method: 'eth_sendTransaction', params: [{ to: '0x1234' }] });
  assert.equal(calls[0].method, 'eth_sendTransaction');
  await assert.rejects(plugin.wallet.request({ method: 'gpc_plugin_storage_set' }));
  await assert.rejects(plugin.storage.set('undefined', undefined));
});
test('ESM exports the same public factory', async () => {
  const sdk = await import('../index.mjs');
  assert.equal(sdk.createPlugin, createPlugin);
});
test('destroy releases all SDK event subscriptions exactly once', () => {
  const removed = [];
  const plugin = createPlugin({ provider: { request: async () => null, on: () => {}, removeListener: (event, handler) => removed.push([event, handler]) } });
  const handler = () => {};
  plugin.on('accountsChanged', handler);
  plugin.gravity.onStop(handler);
  plugin.destroy(); plugin.destroy();
  assert.deepEqual(removed.map(([event]) => event), ['accountsChanged', 'gravityStopped']);
});

test('HTTP popup uses its opener bridge and pins response source and origin', async () => {
  const vm = require('node:vm'), fs = require('node:fs');
  const calls = [], handlers = new Set();
  const peer = { postMessage: (body, origin) => calls.push({ body, origin }), focus() {} };
  const win = { opener: peer, ethereum: { request() { throw Error('external provider must not receive plugin requests'); } }, addEventListener: (_name, fn) => handlers.add(fn), removeEventListener: (_name, fn) => handlers.delete(fn) };
  win.parent = win;
  const context = { window: win, document: { referrer: 'https://wallet.example/' }, setTimeout, clearTimeout, URL };
  vm.runInNewContext(fs.readFileSync(require.resolve('../gpc-plugin.js'), 'utf8'), context);
  const plugin = context.GPCPluginSDK.createPlugin();
  let resolved = false;
  const result = plugin.getContext().then(value => { resolved = true; return value; });
  assert.equal(calls[0].origin, 'https://wallet.example');
  const reply = { type: 'gpc-plugin:response', id: calls[0].body.id, result: { appId: 'owned-app' } };
  for (const handler of handlers) {
    handler({ source: {}, origin: 'https://wallet.example', data: reply });
    handler({ source: peer, origin: 'https://evil.example', data: reply });
  }
  await Promise.resolve(); assert.equal(resolved, false);
  for (const handler of handlers) handler({ source: peer, origin: 'https://wallet.example', data: reply });
  assert.equal((await result).appId, 'owned-app');
  plugin.destroy(); assert.equal(handlers.size, 0);
});
