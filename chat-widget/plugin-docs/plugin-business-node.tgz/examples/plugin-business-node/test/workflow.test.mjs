import { test } from "node:test";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";
import { processEvent } from "../workflow.mjs";
function database() {
  const db = new DatabaseSync(":memory:");
  db.exec(
    "CREATE TABLE events(id TEXT PRIMARY KEY,plan TEXT);CREATE TABLE orders(id TEXT PRIMARY KEY,subject TEXT,amount TEXT,asset TEXT);CREATE TABLE fulfillment(order_id TEXT PRIMARY KEY,created_at INTEGER)",
  );
  return db;
}
test("replayed payment callbacks create one durable fulfillment", async () => {
  const db = database();
  db.prepare("INSERT INTO orders VALUES(?,?,?,?)").run(
    "po_1",
    "subject",
    "100",
    "native",
  );
  const server = {
    orders: {
      get: async () => ({
        id: "po_1",
        subject: "subject",
        amount: "100",
        asset: "native",
        status: "paid",
      }),
    },
  };
  const event = {
    id: "pe_1",
    kind: "order.paid",
    payload: JSON.stringify({ id: "po_1" }),
  };
  await processEvent(db, server, event);
  await processEvent(db, server, event);
  assert.equal(db.prepare("SELECT count(*) AS n FROM fulfillment").get().n, 1);
  db.close();
});
test("a lost card update response retries the same saved version and payload", async () => {
  const db = database();
  db.prepare("INSERT INTO events VALUES(?,NULL)").run("pe_1");
  const calls = [];
  let version = 1;
  const server = {
    cards: {
      get: async () => ({ version }),
      update: async (id, patch) => {
        calls.push({ id, patch });
        if (calls.length === 1) {
          version = 2;
          throw Error("response lost");
        }
        return { version: 2 };
      },
    },
  };
  const event = {
    id: "pe_1",
    kind: "bot.button",
    payload: JSON.stringify({ buttonId: "confirm", messageId: "pbm_1" }),
  };
  await assert.rejects(processEvent(db, server, event), /response lost/);
  await processEvent(db, server, event);
  assert.deepEqual(calls[0], calls[1]);
  assert.equal(calls[1].patch.expectedVersion, 1);
  db.close();
});
