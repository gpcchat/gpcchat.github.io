import http from "node:http";
import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";
import { createServerClient, verifyWebhook } from "../../sdk/plugin/server.mjs";
import { processEvent } from "./workflow.mjs";

const apiKey = process.env.GPC_PLUGIN_API_KEY,
  secret = process.env.GPC_PLUGIN_WEBHOOK_SECRET;
if (!apiKey?.startsWith("gpk_") || !secret)
  throw Error("先配置插件服务端密钥和回调密钥");
const server = createServerClient({
  apiKey,
  apiBase: process.env.GPC_PLUGIN_API_BASE,
});
const db = new DatabaseSync(process.env.DEMO_DB || "./business.sqlite");
db.exec(`PRAGMA journal_mode=WAL;
 CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,payload TEXT NOT NULL,plan TEXT,state TEXT NOT NULL DEFAULT 'pending',attempts INTEGER NOT NULL DEFAULT 0,next_at INTEGER NOT NULL DEFAULT 0,error TEXT);
 CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,subject TEXT NOT NULL,amount TEXT NOT NULL,asset TEXT NOT NULL);
 CREATE TABLE IF NOT EXISTS fulfillment(order_id TEXT PRIMARY KEY,created_at INTEGER NOT NULL);`);
const json = (res, status, value) => {
  res.writeHead(status, {
    "Content-Type": "application/json",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(value));
};
async function body(req, max = 262144) {
  const chunks = [];
  let bytes = 0;
  for await (const c of req) {
    bytes += c.length;
    if (bytes > max) throw Error("请求过大");
    chunks.push(c);
  }
  return Buffer.concat(chunks);
}
http
  .createServer(async (req, res) => {
    try {
      const path = new URL(req.url, "http://localhost").pathname;
      if (req.method === "GET" && path === "/") {
        res.writeHead(200, {
          "Content-Type": "text/html;charset=utf-8",
          "Cache-Control": "no-store",
        });
        res.end(await readFile(new URL("./index.html", import.meta.url)));
        return;
      }
      if (req.method === "GET" && path === "/gpc-plugin.js") {
        res.writeHead(200, { "Content-Type": "application/javascript" });
        res.end(
          await readFile(
            new URL("../../sdk/plugin/gpc-plugin.js", import.meta.url),
          ),
        );
        return;
      }
      if (req.method === "POST" && path === "/api/orders") {
        const input = JSON.parse((await body(req)).toString("utf8"));
        if (
          input.productId !== "ticket" ||
          !/^[a-zA-Z0-9-]{16,64}$/.test(input.requestId) ||
          typeof input.customerAuthorization !== "string"
        )
          return json(res, 400, { error: "商品或请求无效" });
        const order = await server.orders.create({
          customerAuthorization: input.customerAuthorization,
          reference: "demo-" + input.requestId,
          title: "活动票（示例）",
          asset: process.env.DEMO_ASSET || "native",
          amount: process.env.DEMO_AMOUNT || "1000000000000000",
          expiresIn: 900,
        });
        db.prepare(
          "INSERT OR IGNORE INTO orders(id,subject,amount,asset) VALUES(?,?,?,?)",
        ).run(order.id, order.subject, order.amount, order.asset);
        return json(res, 200, order);
      }
      if (req.method === "POST" && path === "/webhook") {
        const rawBody = await body(req);
        if (
          !verifyWebhook({
            secret,
            timestamp: req.headers["x-gpc-timestamp"],
            eventId: req.headers["x-gpc-event-id"],
            signature: req.headers["x-gpc-signature"],
            rawBody,
          })
        )
          return json(res, 401, { error: "签名无效" });
        const event = JSON.parse(rawBody.toString("utf8"));
        if (
          event.id !== req.headers["x-gpc-event-id"] ||
          typeof event.kind !== "string"
        )
          return json(res, 400, { error: "事件无效" });
        db.prepare("INSERT OR IGNORE INTO events(id,payload) VALUES(?,?)").run(
          event.id,
          rawBody.toString("utf8"),
        );
        return json(res, 202, { accepted: true });
      }
      json(res, 404, { error: "接口不存在" });
    } catch (e) {
      json(res, e.status || 400, { error: e.code || e.message });
    }
  })
  .listen(Number(process.env.PORT || 4198), "127.0.0.1", () =>
    process.stdout.write(
      "插件业务示例已监听 loopback；请通过自己的公网 HTTP/HTTPS 域名接入\n",
    ),
  );
let running = false;
const timer = setInterval(async () => {
  if (running) return;
  running = true;
  try {
    const jobs = db
      .prepare(
        "SELECT * FROM events WHERE state='pending' AND next_at<=? ORDER BY rowid LIMIT 20",
      )
      .all(Date.now());
    for (const job of jobs) {
      try {
        await processEvent(db, server, JSON.parse(job.payload));
        db.prepare("UPDATE events SET state='done',error=NULL WHERE id=?").run(
          job.id,
        );
      } catch (e) {
        const attempts = job.attempts + 1;
        db.prepare(
          "UPDATE events SET attempts=?,next_at=?,state=?,error=? WHERE id=?",
        ).run(
          attempts,
          Date.now() + Math.min(300000, 1000 * 2 ** attempts),
          attempts >= 10 ? "failed" : "pending",
          String(e.code || e.message).slice(0, 300),
          job.id,
        );
      }
    }
  } finally {
    running = false;
  }
}, 1000);
process.on("SIGTERM", () => {
  clearInterval(timer);
  db.close();
  process.exit(0);
});
