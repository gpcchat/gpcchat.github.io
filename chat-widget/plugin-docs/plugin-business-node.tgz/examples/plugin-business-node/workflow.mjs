// Durable jobs retain each external request before sending it. Retrying an
// acknowledged card update reuses exactly the same version and idempotency key.
export async function processEvent(db, server, event) {
  const payload =
    typeof event.payload === "string"
      ? JSON.parse(event.payload)
      : event.payload;
  if (event.kind === "order.paid") {
    const order = await server.orders.get(payload.id);
    const local = db.prepare("SELECT * FROM orders WHERE id=?").get(order.id);
    if (!local) return;
    if (
      order.status !== "paid" ||
      order.amount !== local.amount ||
      order.asset !== local.asset ||
      order.subject !== local.subject
    )
      throw Error("订单核验不一致");
    db.prepare(
      "INSERT OR IGNORE INTO fulfillment(order_id,created_at) VALUES(?,?)",
    ).run(order.id, Date.now());
    return;
  }
  if (event.kind === "bot.command") {
    await server.cards.send({
      installationId: payload.installationId,
      idempotencyKey: event.id + ":reply",
      title: "活动助手",
      text: "点击按钮确认参加示例活动。",
      status: "待确认",
      buttons: [{ id: "confirm", label: "确认参加", data: "demo-signup" }],
    });
    return;
  }
  if (event.kind === "bot.button" && payload.buttonId === "confirm") {
    const row = db.prepare("SELECT plan FROM events WHERE id=?").get(event.id);
    let plan = row?.plan ? JSON.parse(row.plan) : null;
    if (!plan) {
      const card = await server.cards.get(payload.messageId);
      plan = {
        idempotencyKey: event.id + ":confirm",
        expectedVersion: card.version,
        text: "报名已经确认。",
        status: "已报名",
        buttons: [{ id: "confirm", label: "已完成", disabled: true }],
      };
      db.prepare("UPDATE events SET plan=? WHERE id=? AND plan IS NULL").run(
        JSON.stringify(plan),
        event.id,
      );
      plan = JSON.parse(
        db.prepare("SELECT plan FROM events WHERE id=?").get(event.id).plan,
      );
    }
    await server.cards.update(payload.messageId, plan);
  }
}
